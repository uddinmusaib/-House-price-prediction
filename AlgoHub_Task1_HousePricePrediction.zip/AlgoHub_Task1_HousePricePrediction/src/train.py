"""
train.py
--------
Trains Linear Regression and Random Forest Regressor models on the house
price dataset, evaluates them, and saves the best model + zip-code frequency
map to disk using joblib.
"""

import json
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from preprocess import full_pipeline


def evaluate(name, model, X_test, y_test):
    preds = model.predict(X_test)
    mae = mean_absolute_error(y_test, preds)
    rmse = np.sqrt(mean_squared_error(y_test, preds))
    r2 = r2_score(y_test, preds)
    print(f"\n{name}")
    print(f"  MAE  : {mae:,.2f}")
    print(f"  RMSE : {rmse:,.2f}")
    print(f"  R2   : {r2:.4f}")
    return {"model": name, "mae": mae, "rmse": rmse, "r2": r2}


def main():
    X, y, df = full_pipeline("data/house_data.csv")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    results = []

    # ---- Linear Regression ----
    lr = LinearRegression()
    lr.fit(X_train, y_train)
    results.append(evaluate("Linear Regression", lr, X_test, y_test))

    # ---- Random Forest Regressor ----
    rf = RandomForestRegressor(
        n_estimators=200, max_depth=12, random_state=42, n_jobs=-1
    )
    rf.fit(X_train, y_train)
    results.append(evaluate("Random Forest Regressor", rf, X_test, y_test))

    # ---- Pick best model by R2 ----
    best = max(results, key=lambda r: r["r2"])
    print(f"\nBest model: {best['model']} (R2 = {best['r2']:.4f})")

    best_model = rf if best["model"] == "Random Forest Regressor" else lr

    # Save model
    joblib.dump(best_model, "model.pkl")

    # Save zip_code frequency map (needed at inference time in the Streamlit app)
    freq_map = df.set_index("zip_code")["zip_code_freq"].to_dict()
    # Reconstruct a clean unique zip -> freq map from the original (pre-feature-engineered) df
    zip_counts = pd.read_csv("data/house_data.csv")["zip_code"].value_counts().to_dict()
    joblib.dump(zip_counts, "zip_freq_map.pkl")

    # Save metrics for the README / report
    with open("metrics.json", "w") as f:
        json.dump(results, f, indent=2)

    print("\nSaved model.pkl, zip_freq_map.pkl, and metrics.json")


if __name__ == "__main__":
    main()
