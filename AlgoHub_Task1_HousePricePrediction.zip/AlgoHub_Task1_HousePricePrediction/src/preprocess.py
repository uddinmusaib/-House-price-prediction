"""
preprocess.py
--------------
Data loading and preprocessing utilities for the House Price Prediction project.
"""

import pandas as pd
import numpy as np


def load_data(path: str) -> pd.DataFrame:
    """Load raw CSV data."""
    df = pd.read_csv(path)
    # Drop unnamed index column if present (common artifact when CSV was saved with index=True)
    if "Unnamed: 0" in df.columns:
        df = df.drop(columns=["Unnamed: 0"])
    return df


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Basic cleaning: drop duplicates, handle missing values, remove invalid rows."""
    df = df.copy()
    df = df.drop_duplicates()

    # Drop rows with any missing values (dataset is already clean, but kept for robustness)
    df = df.dropna()

    # Remove impossible / invalid entries
    df = df[(df["beds"] > 0) & (df["baths"] > 0) & (df["size"] > 0) & (df["price"] > 0)]

    return df


def remove_outliers(df: pd.DataFrame, column: str = "price") -> pd.DataFrame:
    """Remove extreme outliers using the IQR method on the target column."""
    q1 = df[column].quantile(0.25)
    q3 = df[column].quantile(0.75)
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    return df[(df[column] >= lower) & (df[column] <= upper)]


def feature_engineering(df: pd.DataFrame) -> pd.DataFrame:
    """Create additional features that help the model."""
    df = df.copy()
    df["price_per_sqft"] = df["price"] / df["size"]  # used only for EDA, not as a model input
    df["beds_baths_total"] = df["beds"] + df["baths"]
    return df


def encode_zip(df: pd.DataFrame) -> pd.DataFrame:
    """Frequency-encode zip_code (treated as categorical location feature)."""
    df = df.copy()
    freq_map = df["zip_code"].value_counts().to_dict()
    df["zip_code_freq"] = df["zip_code"].map(freq_map)
    return df


def get_feature_target(df: pd.DataFrame):
    """Return X (features) and y (target) ready for model training."""
    feature_cols = ["beds", "baths", "size", "zip_code_freq", "beds_baths_total"]
    X = df[feature_cols]
    y = df["price"]
    return X, y


def full_pipeline(path: str):
    """Run the full preprocessing pipeline and return X, y, and the cleaned dataframe."""
    df = load_data(path)
    df = clean_data(df)
    df = remove_outliers(df, "price")
    df = feature_engineering(df)
    df = encode_zip(df)
    X, y = get_feature_target(df)
    return X, y, df


if __name__ == "__main__":
    X, y, df = full_pipeline("data/house_data.csv")
    print("Final shape:", df.shape)
    print(X.head())
