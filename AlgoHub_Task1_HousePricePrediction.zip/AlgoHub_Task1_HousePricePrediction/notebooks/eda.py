"""
eda.py
------
Exploratory Data Analysis for the House Price dataset.
Generates summary stats and saves key plots used in the project README / demo video.
"""

import sys
sys.path.append("../src")

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("../data/house_data.csv")
if "Unnamed: 0" in df.columns:
    df = df.drop(columns=["Unnamed: 0"])

print("Shape:", df.shape)
print(df.describe())
print("\nMissing values:\n", df.isnull().sum())

# Correlation heatmap
plt.figure(figsize=(6, 5))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Feature Correlation Heatmap")
plt.tight_layout()
plt.savefig("../screenshots/correlation_heatmap.png", dpi=150)
plt.close()

# Price distribution
plt.figure(figsize=(6, 4))
sns.histplot(df["price"], bins=40, kde=True)
plt.title("House Price Distribution")
plt.xlabel("Price ($)")
plt.tight_layout()
plt.savefig("../screenshots/price_distribution.png", dpi=150)
plt.close()

# Size vs Price scatter
plt.figure(figsize=(6, 4))
sns.scatterplot(data=df, x="size", y="price", hue="beds", palette="viridis")
plt.title("Size vs Price (colored by Bedrooms)")
plt.tight_layout()
plt.savefig("../screenshots/size_vs_price.png", dpi=150)
plt.close()

print("\nSaved plots to screenshots/ folder.")
